import sqlite3


def prvi_slobodni(lista_id):
    for i in range(0, len(lista_id)):
        if (i + 1) not in lista_id:
            return i + 1
    return len(lista_id) + 1


class BazaPodataka():
    def __init__(self,filename):
        self.conn=sqlite3.Connection(filename)
        self.cur=self.conn.cursor()
        self.cur.executescript("""
            CREATE TABLE IF NOT EXISTS Clan(
              clanID integer PRIMARY KEY,
              ime text NOT NULL,
              prezime text NOT NULL,
              email text NOT NULL,
              clan_do DATETIME NOT NULL);

                                      
            CREATE TABLE IF NOT EXISTS Autor(
              autorID integer PRIMARY KEY,
              ime_prezime text NOT NULL);
            
            CREATE TABLE IF NOT EXISTS Vrsta(
              vrstaID integer PRIMARY KEY,
              naziv text NOT NULL);
            
            CREATE TABLE IF NOT EXISTS Knjiga(
              knjigaID integer PRIMARY KEY,
              naslov text NOT NULL,
              vrstaID integer NOT NULL,             
              FOREIGN KEY (vrstaID) REFERENCES Vrsta (vrstaID));
            
            CREATE TABLE IF NOT EXISTS Knjiga_Autor(
              autorID integer NOT NULL,
              knjigaID integer NOT NULL,
              PRIMARY KEY (autorID,knjigaID),
              FOREIGN KEY (autorID) REFERENCES Autor (autorID),
              FOREIGN KEY (knjigaID) REFERENCES Knjiga (knjigaID)
              );
            
                        
            CREATE TABLE IF NOT EXISTS Posudba(
              clanID integer NOT NULL,
              knjigaID integer NOT NULL,
              datum_povratka DATETIME NOT NULL,
              PRIMARY KEY (clanID,knjigaID),              
              FOREIGN KEY (clanID) REFERENCES Clan (clanID),
              FOREIGN KEY (knjigaID) REFERENCES Knjiga (knjigaID));""")


    def insertCLan(self,ime,prezime,email,datum):
        self.cur.execute("""SELECT clanID FROM Clan""")
        id = self.cur.fetchall()
        ime=ime.title()
        prezime=prezime.title()
        id = [int(i[0]) for i in id]
        clanID = prvi_slobodni(id)
        self.cur.execute("""
            INSERT INTO Clan
            (clanID, ime, prezime, email, clan_do)
            VALUES (?, ?, ?, ?,?)""", (clanID, ime, prezime, email, datum))
        self.conn.commit()

    def selectClan(self):
        self.cur.execute("""SELECT * FROM Clan""")
        return self.cur.fetchall()



    def selectKnjiga(self):
        self.cur.execute("""SELECT k.knjigaID, k.naslov, v.naziv, a.ime_prezime FROM Knjiga k  INNER JOIN Vrsta v ON k.vrstaID=v.vrstaID INNER JOIN Knjiga_Autor ka ON k.knjigaID=ka.knjigaID INNER JOIN Autor a ON ka.autorID=a.autorID """)
        return self.cur.fetchall()

    def insertKnjiga(self,naslov, vrsta, autor):
        self.cur.execute("""SELECT knjigaID FROM Knjiga""")
        id = self.cur.fetchall()
        id = [int(i[0]) for i in id]
        knjigaID = prvi_slobodni(id)
        vrsta=vrsta.title()
        autor=autor.title()
        naslov=naslov.title()
        self.cur.execute("""SELECT vrstaID FROM Vrsta where naziv=?""",(vrsta,))
        vrsta_niz=self.cur.fetchall()
        if  len(vrsta_niz)==0:
            self.cur.execute("""SELECT vrstaID FROM Vrsta""")
            id = self.cur.fetchall()
            id = [int(i[0]) for i in id]
            vrstaID = prvi_slobodni(id)
            self.cur.execute("""
                INSERT INTO Vrsta
                (vrstaID, naziv)
                VALUES (?, ?)""", (vrstaID, vrsta))
            self.conn.commit()
        else:
            vrstaID=vrsta_niz[0][0]

        self.cur.execute("""SELECT autorID FROM Autor where ime_prezime=?""",(autor,))
        autor_niz=self.cur.fetchall()
        if  len(autor_niz)==0:
            self.cur.execute("""SELECT autorID FROM Autor""")
            id = self.cur.fetchall()
            id = [int(i[0]) for i in id]
            autorID = prvi_slobodni(id)
            self.cur.execute("""
                INSERT INTO Autor
                (autorID, ime_prezime)
                VALUES (?, ?)""", (autorID, autor))
            self.conn.commit()
        else:
            autorID=autor_niz[0][0]

        self.cur.execute("""
            INSERT INTO Knjiga
            (knjigaID, naslov, vrstaID)
            VALUES (?, ?, ?)""", (knjigaID, naslov, vrstaID))
        self.conn.commit()

        self.cur.execute("""SELECT autorID FROM Knjiga_Autor where autorID=? and knjigaID=?""", (autorID,knjigaID))
        knjiga_autor = self.cur.fetchall()
        if len(knjiga_autor)==0:
            self.cur.execute("""
                INSERT INTO Knjiga_Autor
                (knjigaID, autorID)
                VALUES (?, ?)""", (knjigaID,  autorID))
            self.conn.commit()

    def deleteClan(self,clanID):
        self.cur.execute("""
            DELETE FROM Clan
            WHERE clanID= ?""", ( clanID,))
        self.conn.commit()

    def deleteKNjiga(self,knjigaID):
        self.cur.execute("""
            DELETE FROM Knjiga
            WHERE knjigaID= ?""", ( knjigaID,))
        self.conn.commit()

    def clanPodaci(self,clanID):
        self.cur.execute("""SELECT * FROM Clan WHERE ClanID=?""",(clanID,))
        return self.cur.fetchall()

    def posudjeneKnjige(self,clanID):
        self.cur.execute("""SELECT k.knjigaID, k.naslov, v.naziv, a.ime_prezime, p.datum_povratka FROM Knjiga k  INNER JOIN Vrsta v ON k.vrstaID=v.vrstaID INNER JOIN Knjiga_Autor ka ON k.knjigaID=ka.knjigaID INNER JOIN Autor a ON ka.autorID=a.autorID INNER JOIN Posudba p ON p.knjigaID=k.knjigaID WHERE p.clanID=? """,(clanID,))
        return self.cur.fetchall()

    def dostupneKnjige(self):
        self.cur.execute("""SELECT k.knjigaID, k.naslov, v.naziv, a.ime_prezime FROM Knjiga k  INNER JOIN Vrsta v ON k.vrstaID=v.vrstaID INNER JOIN Knjiga_Autor ka ON k.knjigaID=ka.knjigaID INNER JOIN Autor a ON ka.autorID=a.autorID  WHERE k.knjigaID   NOT IN (SELECT knjigaID FROM Posudba) """)
        return self.cur.fetchall()

    def napraviPosudbu(self,clanID,knjigaID,datum):
        self.cur.execute("""
            INSERT INTO Posudba
            (clanID, knjigaID, datum_povratka)
            VALUES (?, ?, ?)""", (clanID, knjigaID, datum))
        self.conn.commit()

    def vratiKnjigu(self,clanID,knjigaID):
        self.cur.execute("""
            DELETE FROM Posudba
            WHERE clanID= ? and knjigaID=?""", (clanID,knjigaID))
        self.conn.commit()

    def produziClanarinu(self,datum,clanID):
        self.cur.execute("""UPDATE Clan SET
                            clan_do = ? WHERE clanID=?""",(datum,clanID))
        self.conn.commit()

    def knjigaInfo(self,knjigaID):
            self.cur.execute(
                """SELECT k.knjigaID, k.naslov, v.naziv, a.ime_prezime FROM Knjiga k  INNER JOIN Vrsta v ON k.vrstaID=v.vrstaID INNER JOIN Knjiga_Autor ka ON k.knjigaID=ka.knjigaID INNER JOIN Autor a ON ka.autorID=a.autorID WHERE k.knjigaID=? """,(knjigaID,))
            knjiga= self.cur.fetchall()[0]
            self.cur.execute("""SELECT * FROM  Posudba WHERE knjigaID=? """,(knjigaID))
            posudba=self.cur.fetchall()
            if(len(posudba)==0):
                return (knjiga,)
            else:
                posudba=posudba[0]
                claninfo=self.clanPodaci(posudba[0])[0]
                return (knjiga,claninfo,posudba[2])

    def clan_edit(self, clanID, ime, prezime, email):
        ime, prezime = ime.title(),prezime.title()
        self.cur.execute("""UPDATE Clan SET
                            ime = ?, prezime = ?, email = ? WHERE clanID = ? """, (ime, prezime, email, clanID))
        self.conn.commit()


    def postojiPosudba(self,knjigaID=None,clanID=None):
        if clanID is None:
            self.cur.execute("""SELECT * FROM Posudba WHERE knjigaID=?""",(knjigaID,))
            return len(self.cur.fetchall())!=0
        else:
            self.cur.execute("""SELECT * FROM Posudba WHERE clanID=?""",(clanID,))
            return len(self.cur.fetchall()) != 0



















































