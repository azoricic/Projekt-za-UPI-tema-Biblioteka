class Clan():
    def __init__(self, clanID, ime,prezime,email):
        self._clanID = clanID
        self._ime = ime
        self._prezime = prezime
        self._email=email

    @property
    def clanID(self):
        return self._clanID

    @property
    def ime(self):
        return self._ime

    @property
    def prezime(self):
        return self._prezime
    
    @property
    def email(self):
        return self._email
	
    def __str__(self):
        return """
        clanID: {0}
        ime: {1}
        prezime: {2}
	email: {3}
        ----------------
        """.format(self._clanID, self._ime,self._prezime,self._email)
