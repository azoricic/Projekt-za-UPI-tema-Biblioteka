class Knjiga():
    def __init__(self, knjigaID, naziv, vrstaID):
        self._autrorID = autorID
        self._naziv = naziv
        self._vrstaID=vrstaID

        

    @property
    def knjigaID(self):
        return self._knjigaiD

    @property
    def naziv(self):
        return self._naziv
    
    @property
    def vrstaID(self):
        return self._vrstaID

	
    def __str__(self):
        return """
        knjigaID: {0}
        naziv: {1}
        vrstaID: {2}
        ----------------
        """.format(self._knjigaID, self._naziv, self._vrstaID)

