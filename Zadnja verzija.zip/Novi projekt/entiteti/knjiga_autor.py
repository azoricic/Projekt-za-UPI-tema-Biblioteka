class Knjiga_Autor():
    def __init__(self,autorID,knjigaID):
        self._autorID=autorID
        self._knjigaID=knjigaID

    @property
    def autorID(self):
        return self._autorID
    
    @property
    def knjigaID(self):
        return self._knjigaID

    
    def __str__(self):
        return """
        autorID: {0}
        knjigaID: {1}
        ----------------
        """.format(self._autorID,self._knjigaID)


