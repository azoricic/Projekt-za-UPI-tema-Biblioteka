class Vrsta():
    def __init__(self,vrstaID,naziv):
        self._vrstaID=vrstaID
        self._naziv=naziv

    @property
    def vrstaID(self):
        return self._vrstaID
    
    @property
    def naziv(self):
        return self._naziv

    
    def __str__(self):
        return """
        vrstaID: {0}
        naziv: {1}
        ----------------
        """.format(self._vrstaID,self._naziv)
