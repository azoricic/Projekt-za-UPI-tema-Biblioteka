import sys
import os
import unittest
from itertools import permutations
from model import *
if __name__=='__main__':
    sys.path.append(os.path.abspath(".."))
from entiteti.poruka import Poruka

class TestTrokut(unittest.TestCase):      
    def setUp(self):
        unesi_demo_podatke()
    def tearDown(self):
        os.remove("baza.db")
    def test_init_type_error_string_arg(self):
        with self.assertRaises(TypeError):
            Poruka(1,"Hello","r",3,0)
    def test_init_type_error_string_arg_2(self):
        with self.assertRaises(TypeError):
            Poruka(1,"Hello",3,"r",0)
    def test_init_type_error_string_arg_3(self):
        with self.assertRaises(TypeError):
            Poruka(1,"Hello",2,3,0)

    def test_select_clana_po_nazivu_ispravno(self):
        insertCLan('Ana')
        self.assertCountEqual([selectClan('Ana').ime],['Ana']) 

    def test_select_clan_po_nazivu_krivo(self):
        insertCLan("Ana")
        self.assertIsNone(selectClan('ime'))   
        
    def test_select_clan_po_id_ispravno(self):
        insertCLan("Ana")
        d=selectClan(1)
        self.assertCountEqual([d.clanID],[1])

    def test_select_clan_po_id_krivo(self):
        insertCLan('Ana')
        self.assertIsNone(selectClan('ime'))

    def test_update_clan_ispravno(self):
        insertCLan("Ana")
        clan_edit(1,'Ivana')
        dd=selectClan()
        for d in dd:
            self.assertCountEqual([(d.clanID,d.ime)],[(1,'Ivana')])   

    def test_delete_clana(self):
        insertCLan('Ana')
        insertCLan('Ivana')
        deleteClan(1)
        dd=selectClan()
        for d in dd:
            self.assertCountEqual((d.clanID,d.ime), (2,'Ivana'))

    def test_insert_clana(self):
        insertCLan('Ana')
        insertCLan('Ivana')
        self.assertCountEqual([selectClan('Ana').clanID], [1])
        self.assertCountEqual([selectClan('Ivana').clanID],[2])

    
if __name__=='__main__':
    unittest.main()
