from bottle import template

class View():
    @staticmethod
    def naslovna():
        return template('html/login')

    @staticmethod
    def naslovna_losa():
        return template('html/los_unos')

    @staticmethod
    def administracija():
        return  template('html/administracija')

    @staticmethod
    def clan_add():
        return template('html/Regist')

    @staticmethod
    def clan_add_dobar():
        return template('html/dodan_clan')

    @staticmethod
    def clan_add_los():
        return template('html/reg_losa')

    @staticmethod
    def clan_popis(clanovi):
        return template('html/popisclanova',clanovi=clanovi)

    @staticmethod
    def knjiga_dodaj():
        return template('html/dodaj_knjigu')

    @staticmethod
    def knjiga_dodaj_losa():
        return template('html/knjiga_losa')

    @staticmethod
    def podatak_dodan():
        return template('html/admin_podatak')

    @staticmethod
    def popis_knjiga(knjige):
        return template('html/popisknjige',knjige=knjige)

    @staticmethod
    def clan_info(podaci, posudbe,duljina):
        return template('html/clan pregled', podaci=podaci, posudbe=posudbe,duljina=duljina)

    @staticmethod
    def clan_info_max(podaci, posudbe, duljina):
        return template('html/max_podizanje', podaci=podaci, posudbe=posudbe, duljina=duljina)

    @staticmethod
    def clan_info_produzi(podaci, posudbe, duljina):
        return template('html/produzi', podaci=podaci, posudbe=posudbe, duljina=duljina)

    @staticmethod
    def clan_info_vracena(podaci, posudbe, duljina):
        return template('html/knjiga_vracena', podaci=podaci, posudbe=posudbe, duljina=duljina)

    @staticmethod
    def clan_info_istekla(podaci, posudbe, duljina):
        return template('html/clan_istekla', podaci=podaci, posudbe=posudbe, duljina=duljina)

    @staticmethod
    def popis_dostupnih_knjiga(clanID,podaci,dostupne):
        return template('html/dostupne knjige', clanID=clanID, podaci=podaci, knjige=dostupne)

    @staticmethod
    def knjiga_info(*args):
        return template('html/knjiga info',arg=args)

    @staticmethod
    def edit_clan(clanID, ime, prezime, email):
        return template('html/edit_clan', clanID=clanID, ime=ime, prezime=prezime, email=email)


    @staticmethod
    def poruka_zakasnina(podaci,posudbe,duljina,zakasnina):
        return template('html/zakasnina', podaci=podaci, posudbe=posudbe, duljina=duljina, zakasnina=zakasnina)

