class Autor():
    def __init__(self, autorID, ime_prezime):
        self._autorID = autorID
        self._ime_prezime = ime_prezime
        

    @property
    def autorID(self):
        return self._autorID

    @property
    def ime_prezime(self):
        return self._ime_prezime

	
    def __str__(self):
        return """
        autorID: {0}
        ime_prezime: {1}
        ----------------
        """.format(self._autorID, self._ime_prezime)
