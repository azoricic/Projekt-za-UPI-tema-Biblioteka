import sys
import os
import unittest
from itertools import permutations
if __name__=='__main__':
    sys.path.append(os.path.abspath(".."))

class Korisnik(object):
    def _init_(ime,password):
         User._ime = ime
         User._password = password
         
    def ime(self):
        return Korisnik._ime

    
    def password(self):
        return Korisnik._password
    
    def __str__(self):
        return ""

    
        ime: {0}
        password: {1}

        "".format(Korisnik._ime,Korisnik._password)
        


if __name__=='__main__':
    unittest.main()

