from bottle import route, redirect, request,run
from view import View
import re
from datetime import  date,timedelta

from model import BazaPodataka
from datetime import  date, timedelta

bp=BazaPodataka('baza.db')
ui=View()


@route('/')
def login():
    return ui.naslovna()

@route('/login', method='POST')
def do_login():
   ime = request.forms.get('ime')
   password = request.forms.get('password')
   if (password =='123' and ime=='korisnik1') or (password=='321' and ime=='korisnik2'):
        redirect('/admin')
   else:
        return ui.naslovna_losa()



@route('/admin')
def administracija_naslovna():
        return ui.administracija()


@route('/admin/registracija')
def clan_dodaj():
    return ui.clan_add()

@route('/reg', method="POST")
def registracijaClana():
    ime = request.forms.get('ime')
    prezime = request.forms.get('prezime')
    email=request.forms.get('email')
    if (validacija_podataka(ime, prezime, email)):
        bp.insertCLan(ime,prezime,email,date.today() +timedelta(days=365))
        return ui.podatak_dodan()
    else:
        return ui.clan_add_los()

@route('/edit/<clanID>')
def uredi(clanID):
    clan,ime,prezime,mail,clanDo=bp.clanPodaci(clanID)[0]
    return ui.edit_clan(clan,ime,prezime,mail)

@route('/submitedit', method='POST')
def promijeni_clana():
    clan=request.forms.get('clanID')
    ime = request.forms.get('ime')
    prezime = request.forms.get('prezime')
    email = request.forms.get('email')
    if (validacija_podataka(ime, prezime, email)):
        bp.clan_edit(clanID=clan, ime=ime, prezime=prezime, email=email)

    redirect('/admin/popisclanova')



def validacija_podataka(ime,prezime,email):
    regex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'

    if  len(ime)<2:
        return False
    if not ime.isalpha():
        return False
    if len(prezime)<2:
        return  False
    if not prezime.isalpha():
        return  False
    if not re.search(regex,email):
        return False
    ime.title()
    prezime.title()
    return True


@route('/admin/dodajknjigu')
def dodajKnjigu():
    return ui.knjiga_dodaj()

@route('/submitknjiga',method="POST")
def prihvatiKnjiga():
    naslov=request.forms.get('naslov')
    autor=request.forms.get('autor')
    vrsta=request.forms.get('vrsta')

    if (validacija_podataka_knjiga(naslov,autor,vrsta)):
        bp.insertKnjiga(naslov, vrsta, autor)
        return ui.podatak_dodan()
    else:
        return ui.knjiga_dodaj_losa()



def validacija_podataka_knjiga(naslov,autor,vrsta):

    if  len(naslov)<2:
        return False
    if len(autor)<2:
        return  False

    if len(vrsta)<2:
        return  False

    vrsta.title()
    autor.title()
    naslov.title()
    return True

@route('/admin/popisclanova')
def popis_clanova():
    return ui.clan_popis(bp.selectClan())

@route('/clansubmit',method="POST")
def brisi_clan():
    clan=request.forms.get('clan')
    action=request.forms.get('action')
    if action=='Izbrisi':
        if( not bp.postojiPosudba(clanID=clan)):
            bp.deleteClan(int(clan))
        redirect('/admin/popisclanova')
    if action == 'Uredi':
        redirect('/edit/'+str(clan))
    if action == 'Pregled':
        redirect('/clan/'+str(clan))

@route('/clan/<clanID>')
def clan_pregled(clanID):
    clanPodaci=bp.clanPodaci(clanID)
    posudjeneKnjige=bp.posudjeneKnjige(clanID)
    duljina=len(posudjeneKnjige)
    return  ui.clan_info(podaci=clanPodaci,posudbe=posudjeneKnjige,duljina=duljina)

@route('/clan2/<clanID>')
def clan_max(clanID):
    clanPodaci=bp.clanPodaci(clanID)
    posudjeneKnjige=bp.posudjeneKnjige(clanID)
    duljina=len(posudjeneKnjige)
    return  ui.clan_info_max(podaci=clanPodaci,posudbe=posudjeneKnjige,duljina=duljina)

@route('/clan3/<clanID>')
def clan_produzi(clanID):
    clanPodaci=bp.clanPodaci(clanID)
    posudjeneKnjige=bp.posudjeneKnjige(clanID)
    duljina=len(posudjeneKnjige)
    return  ui.clan_info_produzi(podaci=clanPodaci,posudbe=posudjeneKnjige,duljina=duljina)

@route('/clan4/<clanID>')
def clan_vracena(clanID):
    clanPodaci=bp.clanPodaci(clanID)
    posudjeneKnjige=bp.posudjeneKnjige(clanID)
    duljina=len(posudjeneKnjige)
    return  ui.clan_info_vracena(podaci=clanPodaci,posudbe=posudjeneKnjige,duljina=duljina)

@route('/clan5/<clanID>')
def clan_istekla(clanID):
    clanPodaci=bp.clanPodaci(clanID)
    posudjeneKnjige=bp.posudjeneKnjige(clanID)
    duljina=len(posudjeneKnjige)
    return  ui.clan_info_istekla(podaci=clanPodaci,posudbe=posudjeneKnjige,duljina=duljina)

@route('/clan6/<clanID>/<zak>')
def clan_zakasnina(clanID,zak):
    clanPodaci=bp.clanPodaci(clanID)
    posudjeneKnjige=bp.posudjeneKnjige(clanID)
    duljina=len(posudjeneKnjige)
    return  ui.poruka_zakasnina(podaci=clanPodaci,posudbe=posudjeneKnjige,duljina=duljina,zakasnina=zak)



@route('/pristup_posudbi', method="POST")
def provjera_mogucnosti_posudbe():
    clan=int(request.forms.get('clan'))
    d =request.forms.get('datum')
    broj=int(request.forms.get('duljina'))
    g, m, d = d.split('-')
    datum=date(int(g),int(m),int(d))
    if(broj==3):
        redirect('/clan2/'+str(clan))
    elif (datum<=date.today()):
        redirect('/clan5/' + str(clan))
    else:
        redirect('/posudba/'+ str(clan))

@route('/posudba/<clanID>')
def popis_dostupnih_knjiga(clanID):
    clanPodaci=bp.clanPodaci(clanID)
    dostupne=bp.dostupneKnjige()
    return ui.popis_dostupnih_knjiga(clanID=clanID, podaci=clanPodaci,dostupne=dostupne)


@route('/posudba', method="POST")
def posudba():
    clan=int(request.forms.get('clan'))
    knjiga=int(request.forms.get('knjiga'))
    bp.napraviPosudbu(clanID=clan,knjigaID=knjiga,datum=date.today()+timedelta(days=30))
    redirect('/clan/'+str(clan))


@route('/produziclanarnu', method='POST')
def produzi():
    clan=int(request.forms.get('clan'))
    d =request.forms.get('datum')
    g, m, d = d.split('-')
    datum = date(int(g), int(m), int(d))
    razlika=datum -date.today()
    dani=razlika.days
    if(dani<=30):
        datum=datum+timedelta(days=365)
        bp.produziClanarinu(datum=datum,clanID=clan)
        redirect('/clan/'+str(clan))
    else:
        redirect('/clan3/'+str(clan))


@route('/vratiknjigu',method="POST")
def vrati_knjigu():
    clan=int(request.forms.get('clan'))
    knjiga=int(request.forms.get('knjiga'))
    d =request.forms.get('datum')
    g, m, d = d.split('-')
    datum = date(int(g), int(m), int(d))
    razlika=datum-date.today()
    razlika=razlika.days
    if(razlika>=0):
        bp.vratiKnjigu(clanID=clan,knjigaID=knjiga)
        redirect('/clan4/'+str(clan))
    else:
        zakasnina = abs(razlika) * 0.50
        bp.vratiKnjigu(clanID=clan, knjigaID=knjiga)
        redirect('/clan6/'+str(clan)+'/'+str(zakasnina))


@route('/admin/popis_knjiga')
def popis_knjiga():
    print(bp.dostupneKnjige())
    return ui.popis_knjiga(bp.selectKnjiga())

@route('/knjiga_uredi/<knjigaID>')
def knjiga_uredi(knjigaID):
    info=bp.knjigaInfo(knjigaID)
    return ui.edit_knjiga(knjigaID)


@route('/knjigadelete',method="POST")
def knjiga_submit():
    knjiga=request.forms.get('knjiga')
    action=request.forms.get('action')
    if action=='Izbrisi':
       if(not bp.postojiPosudba(knjigaID=knjiga)):
           bp.deleteKNjiga(int(knjiga))
       redirect('/admin/popis_knjiga')
    else:
        redirect('/knjiga/'+str(knjiga))


@route('/knjiga/<knjigaID>')
def knjiga_info(knjigaID):
    info=bp.knjigaInfo(knjigaID)
    if (len(info)==3):
        knjiga,clan,krajPosudbe=info[0],info[1],info[2]
        print(clan[4])
        return ui.knjiga_info(knjiga,clan,krajPosudbe)
    else:
        knjiga=info[0]
        return ui.knjiga_info(knjiga)


























if __name__=='__main__':
    run(reloader=True,port=8080)